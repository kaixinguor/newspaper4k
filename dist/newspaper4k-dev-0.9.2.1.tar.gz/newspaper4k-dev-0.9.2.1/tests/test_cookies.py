import pytest


class TestCookies:
    @pytest.mark.skip(reason="Not implemented yet")
    def test_cookie_requests(self):
        pass
