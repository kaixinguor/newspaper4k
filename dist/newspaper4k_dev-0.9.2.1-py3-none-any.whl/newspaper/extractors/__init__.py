from newspaper.extractors.content_extractor import ContentExtractor

__all__ = ["ContentExtractor"]
